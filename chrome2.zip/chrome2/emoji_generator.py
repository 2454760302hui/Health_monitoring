import torch
from diffusers import StableDiffusionPipeline
import os

class EmojiGenerator:
    def __init__(self):
        print("初始化表情包生成器...")
        try:
            # 初始化Stable Diffusion模型
            self.model_id = "runwayml/stable-diffusion-v1-5"
            self.pipe = StableDiffusionPipeline.from_pretrained(
                self.model_id,
                torch_dtype=torch.float16,
                use_safetensors=True
            )
            
            # 如果有GPU则使用GPU
            if torch.cuda.is_available():
                print("使用GPU进行生成...")
                self.pipe = self.pipe.to("cuda")
            else:
                print("未检测到GPU，使用CPU进行生成（可能较慢）...")
                
        except Exception as e:
            print(f"初始化生成器失败: {str(e)}")
            raise

    def generate_single(self, output_path="generated_emoji.png"):
        """生成单个表情包"""
        try:
            print("开始生成表情包...")
            # 定义提示词
            prompt = "cute cartoon emoji, funny face, kawaii style, simple background, minimalist design, bright colors"
            negative_prompt = "realistic, complex, dark, scary"
            
            # 生成图像
            image = self.pipe(
                prompt=prompt,
                negative_prompt=negative_prompt,
                num_inference_steps=30,
                guidance_scale=7.5
            ).images[0]
            
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
            
            # 保存图像
            image.save(output_path)
            print(f"表情包已生成并保存为: {output_path}")
            return True
            
        except Exception as e:
            print(f"生成表情包时发生错误: {str(e)}")
            return False

    def generate_batch(self, count=5, output_dir="generated_emojis"):
        """批量生成表情包"""
        try:
            # 创建输出目录
            os.makedirs(output_dir, exist_ok=True)
            print(f"输出目录: {output_dir}")
            
            success_count = 0
            for i in range(count):
                print(f"\n正在生成第 {i+1}/{count} 个表情包...")
                output_path = os.path.join(output_dir, f"emoji_{i+1}.png")
                
                if self.generate_single(output_path):
                    success_count += 1
                    
            print(f"\n批量生成完成！成功生成 {success_count}/{count} 个表情包")
            if success_count > 0:
                print(f"生成的表情包保存在目录: {os.path.abspath(output_dir)}")
            
        except Exception as e:
            print(f"批量生成表情包时发生错误: {str(e)}")

def generate_emoji():
    """生成单个表情包的便捷函数"""
    try:
        generator = EmojiGenerator()
        return generator.generate_single()
    except Exception as e:
        print(f"生成表情包失败: {str(e)}")
        return False

def generate_multiple_emojis(count=5):
    """批量生成表情包的便捷函数"""
    try:
        if count <= 0:
            print("生成数量必须大于0")
            return False
        generator = EmojiGenerator()
        return generator.generate_batch(count)
    except Exception as e:
        print(f"批量生成表情包失败: {str(e)}")
        return False

if __name__ == "__main__":
    try:
        # 测试生成单个表情包
        print("测试生成单个表情包...")
        generate_emoji()
        
        # 测试批量生成
        print("\n测试批量生成表情包...")
        generate_multiple_emojis(2)
        
    except Exception as e:
        print(f"测试失败: {str(e)}") 