import sys
import pkg_resources
import subprocess
import os

def check_dependencies():
    """检查并安装必要的依赖"""
    required_packages = {
        'opencv-python': 'opencv-python',
        'numpy': 'numpy',
        'torch': 'torch',
        'diffusers': 'diffusers',
        'transformers': 'transformers',
        'Pillow': 'Pillow'  # 用于处理中文显示
    }
    
    print("检查依赖项...")
    missing_packages = []
    
    for package, pip_name in required_packages.items():
        try:
            pkg_resources.require(package)
            print(f"✓ {package} 已安装")
        except pkg_resources.DistributionNotFound:
            missing_packages.append(pip_name)
            print(f"✗ 未找到 {package}")
    
    if missing_packages:
        print("\n需要安装以下依赖:")
        for package in missing_packages:
            print(f"- {package}")
        
        choice = input("\n是否要自动安装这些依赖? (y/n): ")
        if choice.lower() == 'y':
            for package in missing_packages:
                try:
                    print(f"\n正在安装 {package}...")
                    subprocess.check_call([sys.executable, "-m", "pip", "install", package])
                except subprocess.CalledProcessError as e:
                    print(f"安装 {package} 失败: {str(e)}")
                    print("请尝试手动安装该包")
        else:
            print("请手动安装所需依赖后再运行程序")
            sys.exit(1)

def check_font_file():
    """检查中文字体文件"""
    font_paths = [
        "simhei.ttf",
        "C:/Windows/Fonts/simhei.ttf",  # Windows
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",  # Linux
        "/System/Library/Fonts/PingFang.ttc"  # macOS
    ]
    
    for path in font_paths:
        if os.path.exists(path):
            return True
            
    print("警告: 未找到中文字体文件，显示可能会出现乱码")
    print("请确保系统安装了中文字体（如黑体、宋体等）")
    return False

def main_menu():
    """显示主菜单并处理用户选择"""
    while True:
        print("\n=== 智能健康监测与表情包生成系统 ===")
        print("1. 健康监测")
        print("2. 生成表情包")
        print("3. 批量生成表情包")
        print("0. 退出")
        
        choice = input("\n请选择功能 (0-3): ")
        
        if choice == '1':
            from face_detection import FaceDetector
            detector = FaceDetector()
            detector.start_detection()
        
        elif choice == '2':
            from emoji_generator import generate_emoji
            generate_emoji()
        
        elif choice == '3':
            from emoji_generator import generate_multiple_emojis
            try:
                count = int(input("请输入要生成的表情包数量: "))
                if count <= 0:
                    print("生成数量必须大于0")
                    continue
                generate_multiple_emojis(count)
            except ValueError:
                print("请输入有效的数字")
        
        elif choice == '0':
            print("感谢使用！再见！")
            break
        
        else:
            print("无效的选择，请重试")

def show_welcome():
    """显示欢迎信息"""
    print("\n" + "="*50)
    print("欢迎使用智能健康监测与表情包生成系统")
    print("本系统提供以下功能：")
    print("1. 实时人脸检测与健康监测")
    print("   - 基础生理指标监测")
    print("   - 压力与疲劳度分析")
    print("   - 情绪状态评估")
    print("   - 健康建议生成")
    print("2. AI表情包生成")
    print("   - 单张生成")
    print("   - 批量生成")
    print("="*50 + "\n")

if __name__ == "__main__":
    try:
        print("正在初始化程序...")
        check_dependencies()
        check_font_file()
        show_welcome()
        main_menu()
        
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"\n程序发生错误: {str(e)}")
    finally:
        print("\n程序已退出") 