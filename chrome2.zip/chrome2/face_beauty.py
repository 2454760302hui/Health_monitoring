import cv2
import numpy as np

class FaceBeauty:
    def __init__(self):
        print("初始化美颜处理器...")

    def apply_beauty_filter(self, image):
        """应用美颜效果"""
        try:
            # 双边滤波美化（磨皮）
            beauty = cv2.bilateralFilter(image, 9, 75, 75)
            
            # 提亮美白
            lab = cv2.cvtColor(beauty, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            l = clahe.apply(l)
            lab = cv2.merge((l, a, b))
            beauty = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
            
            # 磨皮美化
            gaussian = cv2.GaussianBlur(beauty, (7, 7), 0)
            beauty = cv2.addWeighted(beauty, 0.8, gaussian, 0.2, 0)
            
            # 增强细节
            kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], np.float32)
            beauty = cv2.filter2D(beauty, -1, kernel)
            
            return beauty
            
        except Exception as e:
            print(f"应用美颜效果时出错: {str(e)}")
            return image

    def process_image(self, image_path, output_path="beauty_result.jpg"):
        """处理单张图片"""
        try:
            # 读取图片
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"无法读取图片: {image_path}")
            
            # 对整个图片进行美化处理
            beauty_image = self.apply_beauty_filter(image)
            
            # 保存结果
            cv2.imwrite(output_path, beauty_image)
            print(f"美颜处理完成，结果已保存为: {output_path}")
            return True
            
        except Exception as e:
            print(f"处理图片时出错: {str(e)}")
            return False

    def realtime_beauty(self):
        """实时美颜处理"""
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                raise ValueError("无法打开摄像头")
            
            print("开始实时美颜，按'q'退出，按's'保存当前帧")
            print("按'b'开关美颜效果")
            
            beauty_on = True  # 美颜开关
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                if beauty_on:
                    # 对整个画面进行美化
                    frame = self.apply_beauty_filter(frame)
                
                # 显示美颜状态
                status = "Beauty: ON" if beauty_on else "Beauty: OFF"
                cv2.putText(frame, status, (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # 显示结果
                cv2.imshow('Real-time Beauty (q:quit, s:save, b:beauty on/off)', frame)
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    cv2.imwrite('beauty_snapshot.jpg', frame)
                    print("已保存当前帧到: beauty_snapshot.jpg")
                elif key == ord('b'):
                    beauty_on = not beauty_on
                    print(f"美颜效果: {'开启' if beauty_on else '关闭'}")
                    
        except Exception as e:
            print(f"实时美颜处理时出错: {str(e)}")
            
        finally:
            if 'cap' in locals():
                cap.release()
            cv2.destroyAllWindows()

def main():
    try:
        beauty = FaceBeauty()
        while True:
            print("\n=== 美颜系统 ===")
            print("1. 处理单张图片")
            print("2. 实时美颜")
            print("0. 退出")
            
            choice = input("\n请选择功能 (0-2): ")
            
            if choice == '1':
                image_path = input("请输入图片路径: ")
                beauty.process_image(image_path)
            elif choice == '2':
                beauty.realtime_beauty()
            elif choice == '0':
                break
            else:
                print("无效的选择")
                
    except Exception as e:
        print(f"程序运行出错: {str(e)}")

if __name__ == "__main__":
    main() 