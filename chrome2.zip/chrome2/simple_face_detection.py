import cv2
import numpy as np
import sys
import platform

class SimpleFaceDetector:
    def __init__(self):
        print("初始化简单人脸检测器...")
        try:
            # 加载OpenCV预训练的人脸检测模型
            self.face_cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            )
            if self.face_cascade.empty():
                raise ValueError("无法加载人脸检测模型文件")
        except Exception as e:
            print("初始化人脸检测器失败！")
            print(f"错误信息: {str(e)}")
            raise
        
    def detect_faces(self, image_path):
        print(f"正在处理图片: {image_path}")
        try:
            # 读取图片
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"无法读取图片: {image_path}\n请检查图片路径是否正确，以及图片格式是否支持")
            
            # 检查图片是否为空
            if image.size == 0:
                raise ValueError("图片内容为空")
                
            # 转换为灰度图
            try:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            except Exception:
                raise ValueError("图片格式不正确，无法转换为灰度图")
            
            # 检测人脸
            faces = self.face_cascade.detectMultiScale(
                gray, 
                scaleFactor=1.1, 
                minNeighbors=5,
                minSize=(30, 30)
            )
            
            print(f"检测到 {len(faces)} 个人脸")
            
            # 在每个检测到的人脸上绘制矩形
            for (x, y, w, h) in faces:
                cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
            
            # 保存结果
            output_path = "detected_faces.jpg"
            if not cv2.imwrite(output_path, image):
                raise ValueError(f"无法保存结果图片到: {output_path}\n请检查写入权限和磁盘空间")
            
            print(f"处理后的图片已保存为: {output_path}")
            return len(faces)
            
        except Exception as e:
            print(f"处理图片时发生错误: {str(e)}")
            raise

def check_camera():
    """检查摄像头是否可用并给出详细提示"""
    system = platform.system().lower()
    
    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            error_msg = "\n摄像头初始化失败！可能的原因：\n"
            if system == "windows":
                error_msg += "1. 摄像头未连接或被禁用\n"
                error_msg += "2. 摄像头被其他程序占用\n"
                error_msg += "3. 摄像头驱动程序未正确安装\n"
                error_msg += "\n解决方法：\n"
                error_msg += "1. 检查设备管理器中的摄像头状态\n"
                error_msg += "2. 关闭其他可能使用摄像头的程序\n"
                error_msg += "3. 更新或重新安装摄像头驱动程序"
            elif system == "linux":
                error_msg += "1. 检查摄像头设备是否存在：ls /dev/video*\n"
                error_msg += "2. 确认用户有访问摄像头的权限\n"
                error_msg += "3. 安装必要的驱动：sudo apt-get install v4l-utils"
            elif system == "darwin":  # macOS
                error_msg += "1. 检查系统偏好设置中的隐私权限\n"
                error_msg += "2. 确认是否允许应用访问摄像头\n"
                error_msg += "3. 重新插拔摄像头或重启电脑"
            
            raise ValueError(error_msg)
        return cap
    except Exception as e:
        if not str(e).startswith('\n摄像头初始化失败'):
            print(f"\n访问摄像头时发生错误: {str(e)}")
        raise

def realtime_face_detection():
    print("初始化实时人脸检测...")
    try:
        # 初始化检测器
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        if face_cascade.empty():
            raise ValueError("无法加载人脸检测模型文件")
        
        # 检查并打开摄像头
        cap = check_camera()
        
        print("开始实时检测，按'q'键退出，按's'键保存当前帧")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                raise ValueError("无法从摄像头读取图像")
                
            # 转换为灰度图
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            # 检测人脸
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )
            
            # 在每个检测到的人脸上绘制矩形
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, f'Face', (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            
            # 显示检测到的人脸数量
            cv2.putText(frame, f'Detected: {len(faces)}', (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            
            # 显示结果
            cv2.imshow('Real-time Face Detection (Press q to quit, s to save)', frame)
            
            # 处理键盘输入
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                # 保存当前帧
                cv2.imwrite('face_detection_snapshot.jpg', frame)
                print("已保存当前帧到: face_detection_snapshot.jpg")
    
    except Exception as e:
        print(f"实时人脸检测发生错误: {str(e)}")
        raise
    
    finally:
        # 释放资源
        if 'cap' in locals():
            cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    try:
        # 测试代码
        detector = SimpleFaceDetector()
        detector.detect_faces("test.jpg")  # 替换为实际的图片路径
    except Exception as e:
        print(f"程序执行失败: {str(e)}")
        sys.exit(1)