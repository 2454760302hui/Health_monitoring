1.安装requirements 
pip install -r requirements.txt

2.运行
python main.py

3.乱码问题-未处理

4.其他待定