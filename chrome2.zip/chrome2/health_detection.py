import cv2
import numpy as np
import time
from datetime import datetime
import random
from PIL import Image, ImageDraw, ImageFont
import os

class HealthDetector:
    def __init__(self):
        print("初始化健康检测系统...")
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        self.health_data = {
            'heart_rate': 0,
            'blood_pressure': 0,
            'temperature': 0,
            'oxygen': 0,
        }
        self.last_update = time.time()
        
        # 加载中文字体
        font_path = "simhei.ttf"  # 需要系统安装此字体或提供字体文件
        if not os.path.exists(font_path):
            font_path = "C:/Windows/Fonts/simhei.ttf"  # Windows默认字体路径
        self.font_size = 24
        self.font = ImageFont.truetype(font_path, self.font_size)

    def generate_health_data(self):
        current_time = time.time()
        if current_time - self.last_update >= 2:
            self.health_data['heart_rate'] = random.randint(60, 100)
            self.health_data['blood_pressure'] = random.randint(90, 140)
            self.health_data['temperature'] = round(random.uniform(36.3, 37.2), 1)
            self.health_data['oxygen'] = random.randint(95, 100)
            self.last_update = current_time

    def cv2_add_chinese_text(self, img, text, position, color):
        """将CV2图片转换为PIL图片，添加中文文字后，再转回CV2图片"""
        # CV2图片转PIL图片
        pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        
        # 创建绘制对象
        draw = ImageDraw.Draw(pil_img)
        
        # 绘制文字
        draw.text(position, text, color, font=self.font)
        
        # PIL图片转CV2图片并返回
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    def draw_health_info(self, frame, face_detected):
        self.generate_health_data()
        
        # 显示时间
        current_time = datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")
        frame = self.cv2_add_chinese_text(frame, 
            f"当前时间: {current_time}", 
            (10, 10), 
            (255, 255, 255))
        
        # 显示检测状态
        status = "检测状态: 已检测到人脸" if face_detected else "检测状态: 未检测到人脸"
        color = (0, 255, 0) if face_detected else (255, 0, 0)
        frame = self.cv2_add_chinese_text(frame, 
            status, 
            (10, 40), 
            color)
        
        if face_detected:
            # 心率
            frame = self.cv2_add_chinese_text(frame,
                f"心率: {self.health_data['heart_rate']} 次/分",
                (10, 70),
                (255, 255, 0))
            
            # 血压
            frame = self.cv2_add_chinese_text(frame,
                f"血压: {self.health_data['blood_pressure']} mmHg",
                (10, 100),
                (255, 255, 0))
            
            # 体温
            frame = self.cv2_add_chinese_text(frame,
                f"体温: {self.health_data['temperature']} ℃",
                (10, 130),
                (255, 255, 0))
            
            # 血氧
            frame = self.cv2_add_chinese_text(frame,
                f"血氧: {self.health_data['oxygen']} %",
                (10, 160),
                (255, 255, 0))
            
            # 健康状态
            status = self.evaluate_health_status()
            color = self.get_status_color(status)
            frame = self.cv2_add_chinese_text(frame,
                f"健康状态: {status}",
                (10, 190),
                color)

    def evaluate_health_status(self):
        if (60 <= self.health_data['heart_rate'] <= 100 and
            90 <= self.health_data['blood_pressure'] <= 120 and
            36.3 <= self.health_data['temperature'] <= 37.2 and
            self.health_data['oxygen'] >= 95):
            return "良好"
        elif (55 <= self.health_data['heart_rate'] <= 105 and
              85 <= self.health_data['blood_pressure'] <= 130 and
              36.0 <= self.health_data['temperature'] <= 37.5 and
              self.health_data['oxygen'] >= 92):
            return "正常"
        else:
            return "异常"

    def get_status_color(self, status):
        if status == "良好":
            return (0, 255, 0)  # 绿色
        elif status == "正常":
            return (255, 255, 0)  # 黄色
        else:
            return (255, 0, 0)  # 红色

    def start_detection(self):
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                raise ValueError("无法打开摄像头")
            
            print("开始实时检测，按'q'键退出，按's'键保存截图")
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # 人脸检测
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = self.face_cascade.detectMultiScale(
                    gray, 
                    scaleFactor=1.1,
                    minNeighbors=5,
                    minSize=(30, 30)
                )
                
                face_detected = len(faces) > 0
                
                # 标记检测到的人脸
                for (x, y, w, h) in faces:
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    frame = self.cv2_add_chinese_text(frame,
                        '已检测到人脸',
                        (x, y-30),
                        (0, 255, 0))
                
                # 显示健康信息
                self.draw_health_info(frame, face_detected)
                
                # 显示结果
                cv2.imshow('健康检测系统 (q:退出 s:截图)', frame)
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f'健康检测_{timestamp}.jpg'
                    cv2.imwrite(filename, frame)
                    print(f"截图已保存为: {filename}")
                    
        except Exception as e:
            print(f"检测过程中出错: {str(e)}")
            
        finally:
            if 'cap' in locals():
                cap.release()
            cv2.destroyAllWindows()

def main():
    try:
        detector = HealthDetector()
        detector.start_detection()
    except Exception as e:
        print(f"程序运行出错: {str(e)}")

if __name__ == "__main__":
    main() 