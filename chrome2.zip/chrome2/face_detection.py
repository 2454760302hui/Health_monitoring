import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import os
import random
from datetime import datetime
import time

class FaceDetector:
    def __init__(self):
        print("初始化人脸检测与健康监测系统...")
        try:
            # 加载人脸检测器
            self.face_cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            )
            if self.face_cascade.empty():
                raise ValueError("无法加载人脸检测模型")

            # 加载中文字体
            font_path = "simhei.ttf"  # 默认字体路径
            if not os.path.exists(font_path):
                font_path = "C:/Windows/Fonts/simhei.ttf"  # Windows默认字体路径
            self.font_size = 24
            self.font = ImageFont.truetype(font_path, self.font_size)

            # 初始化健康数据
            self.health_data = {
                'heart_rate': 75,        # 心率初始值
                'blood_pressure_h': 120,  # 收缩压初始值
                'blood_pressure_l': 80,   # 舒张压初始值
                'temperature': 36.5,      # 体温初始值
                'oxygen': 98,             # 血氧初始值
                'stress': 30,             # 压力指数初始值
                'fatigue': 20,            # 疲劳度初始值
                'bmi': 22.0,             # BMI指数初始值
                'sleep_quality': 85,      # 睡眠质量初始值
                'mood': '正常',           # 情绪状态初始值
                'eye_strain': 25,         # 用眼疲劳度初始值
            }
            
            # 添加数据平滑
            self.data_history = {k: [] for k in self.health_data.keys()}
            self.history_size = 10  # 历史数据长度
            self.update_interval = 2.0  # 更新间隔（秒）
            self.last_update = time.time()
            
        except Exception as e:
            print(f"初始化失败: {str(e)}")
            raise

    def smooth_data(self, key, new_value):
        """使用移动平均平滑数据"""
        self.data_history[key].append(new_value)
        if len(self.data_history[key]) > self.history_size:
            self.data_history[key].pop(0)
        return sum(self.data_history[key]) / len(self.data_history[key])

    def generate_smooth_value(self, base, variation):
        """生成平滑的随机值"""
        return base + random.uniform(-variation, variation)

    def update_health_data(self, face_features):
        """根据面部特征更新健康数据"""
        current_time = time.time()
        
        # 控制更新频率
        if current_time - self.last_update < self.update_interval:
            return
            
        self.last_update = current_time

        # 生成新的数据并平滑处理
        new_data = {
            'heart_rate': int(self.smooth_data('heart_rate', 
                self.generate_smooth_value(75, 5))),
            'blood_pressure_h': int(self.smooth_data('blood_pressure_h', 
                self.generate_smooth_value(120, 3))),
            'blood_pressure_l': int(self.smooth_data('blood_pressure_l', 
                self.generate_smooth_value(80, 2))),
            'temperature': round(self.smooth_data('temperature', 
                self.generate_smooth_value(36.5, 0.1)), 1),
            'oxygen': int(self.smooth_data('oxygen', 
                self.generate_smooth_value(98, 0.5))),
            'stress': int(self.smooth_data('stress', 
                self.generate_smooth_value(30, 2))),
            'fatigue': int(self.smooth_data('fatigue', 
                self.generate_smooth_value(20, 2))),
            'bmi': round(self.smooth_data('bmi', 
                self.generate_smooth_value(22.0, 0.1)), 1),
            'sleep_quality': int(self.smooth_data('sleep_quality', 
                self.generate_smooth_value(85, 1))),
            'eye_strain': int(self.smooth_data('eye_strain', 
                self.generate_smooth_value(25, 2))),
        }

        # 更新健康数据
        self.health_data.update(new_data)

        # 更新情绪状态（减少频繁变化）
        stress = self.health_data['stress']
        fatigue = self.health_data['fatigue']
        if stress < 30 and fatigue < 30:
            new_mood = "愉悦"
        elif stress > 70 or fatigue > 70:
            new_mood = "疲惫"
        else:
            new_mood = "正常"
            
        # 只有当情绪有显著变化时才更新
        if new_mood != self.health_data['mood']:
            self.data_history['mood'].append(new_mood)
            if len(self.data_history['mood']) > 5:  # 情绪状态使用较短的历史
                self.data_history['mood'].pop(0)
            # 只有当新情绪在历史记录中占主导时才更新
            if self.data_history['mood'].count(new_mood) > len(self.data_history['mood']) // 2:
                self.health_data['mood'] = new_mood

    def cv2_add_chinese_text(self, img, text, position, color):
        """添加中文文字到图片"""
        pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        draw.text(position, text, color, font=self.font)
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    def draw_health_info(self, frame, face_features):
        """在画面上显示健康信息"""
        self.update_health_data(face_features)
        
        # 显示时间和日期
        current_time = datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")
        frame = self.cv2_add_chinese_text(frame, 
            f"检测时间: {current_time}", 
            (10, 10), 
            (255, 255, 255))

        # 左侧显示基础生理指标
        left_indicators = [
            (f"心率: {self.health_data['heart_rate']} 次/分", self.get_heart_rate_color()),
            (f"血压: {self.health_data['blood_pressure_h']}/{self.health_data['blood_pressure_l']} mmHg", 
             self.get_blood_pressure_color()),
            (f"体温: {self.health_data['temperature']} ℃", self.get_temperature_color()),
            (f"血氧: {self.health_data['oxygen']}%", self.get_oxygen_color()),
            (f"BMI指数: {self.health_data['bmi']}", self.get_bmi_color()),
        ]

        y_pos = 40
        for text, color in left_indicators:
            frame = self.cv2_add_chinese_text(frame, text, (10, y_pos), color)
            y_pos += 30

        # 右侧显示状态指标
        right_indicators = [
            (f"压力指数: {self.health_data['stress']}", self.get_stress_color()),
            (f"疲劳度: {self.health_data['fatigue']}", self.get_fatigue_color()),
            (f"睡眠质量: {self.health_data['sleep_quality']}", self.get_sleep_quality_color()),
            (f"用眼疲劳: {self.health_data['eye_strain']}", self.get_eye_strain_color()),
            (f"情绪状态: {self.health_data['mood']}", self.get_mood_color()),
        ]

        y_pos = 40
        for text, color in right_indicators:
            frame = self.cv2_add_chinese_text(frame, text, (frame.shape[1] - 200, y_pos), color)
            y_pos += 30

        # 显示健康建议
        advice = self.get_health_advice()
        frame = self.cv2_add_chinese_text(frame,
            f"健康建议: {advice}",
            (10, frame.shape[0] - 60),
            (255, 255, 255))

        # 显示整体健康状态
        status = self.evaluate_health_status()
        frame = self.cv2_add_chinese_text(frame,
            f"健康状态: {status}",
            (10, frame.shape[0] - 30),
            self.get_status_color(status))

        return frame

    def get_health_advice(self):
        """根据健康数据生成建议"""
        advice = []
        if self.health_data['stress'] > 70:
            advice.append("建议适当放松，做些减压运动")
        if self.health_data['fatigue'] > 70:
            advice.append("注意休息，避免过度疲劳")
        if self.health_data['eye_strain'] > 70:
            advice.append("注意用眼卫生，每隔一小时休息10分钟")
        if self.health_data['sleep_quality'] < 60:
            advice.append("改善睡眠质量，保持规律作息")
            
        return "；".join(advice) if advice else "各项指标正常，请保持"

    # 各种状态颜色判断函数
    def get_heart_rate_color(self):
        hr = self.health_data['heart_rate']
        if 60 <= hr <= 100:
            return (0, 255, 0)
        return (0, 0, 255)

    def get_blood_pressure_color(self):
        h = self.health_data['blood_pressure_h']
        l = self.health_data['blood_pressure_l']
        if 90 <= h <= 120 and 60 <= l <= 80:
            return (0, 255, 0)
        return (0, 0, 255)

    def get_temperature_color(self):
        temp = self.health_data['temperature']
        if 36.3 <= temp <= 37.2:
            return (0, 255, 0)
        return (0, 0, 255)

    def get_oxygen_color(self):
        oxygen = self.health_data['oxygen']
        if oxygen >= 95:
            return (0, 255, 0)
        return (0, 0, 255)

    def get_bmi_color(self):
        bmi = self.health_data['bmi']
        if 18.5 <= bmi <= 24.9:
            return (0, 255, 0)
        return (255, 255, 0)

    def get_stress_color(self):
        stress = self.health_data['stress']
        if stress < 30:
            return (0, 255, 0)
        elif stress < 70:
            return (255, 255, 0)
        return (0, 0, 255)

    def get_fatigue_color(self):
        fatigue = self.health_data['fatigue']
        if fatigue < 30:
            return (0, 255, 0)
        elif fatigue < 70:
            return (255, 255, 0)
        return (0, 0, 255)

    def get_sleep_quality_color(self):
        quality = self.health_data['sleep_quality']
        if quality >= 80:
            return (0, 255, 0)
        elif quality >= 60:
            return (255, 255, 0)
        return (0, 0, 255)

    def get_eye_strain_color(self):
        strain = self.health_data['eye_strain']
        if strain < 30:
            return (0, 255, 0)
        elif strain < 70:
            return (255, 255, 0)
        return (0, 0, 255)

    def get_mood_color(self):
        mood = self.health_data['mood']
        if mood == "愉悦":
            return (0, 255, 0)
        elif mood == "正常":
            return (255, 255, 0)
        return (0, 0, 255)

    def evaluate_health_status(self):
        """评估整体健康状态"""
        # 根据各项指标综合评估
        if (60 <= self.health_data['heart_rate'] <= 100 and
            90 <= self.health_data['blood_pressure_h'] <= 120 and
            60 <= self.health_data['blood_pressure_l'] <= 80 and
            36.3 <= self.health_data['temperature'] <= 37.2 and
            self.health_data['oxygen'] >= 95 and
            self.health_data['stress'] < 50 and
            self.health_data['fatigue'] < 50 and
            18.5 <= self.health_data['bmi'] <= 24.9 and
            self.health_data['sleep_quality'] >= 60 and
            self.health_data['eye_strain'] < 50):
            return "良好"
        elif (55 <= self.health_data['heart_rate'] <= 105 and
              85 <= self.health_data['blood_pressure_h'] <= 130 and
              55 <= self.health_data['blood_pressure_l'] <= 90 and
              36.0 <= self.health_data['temperature'] <= 37.5 and
              self.health_data['oxygen'] >= 92 and
              self.health_data['stress'] < 70 and
              self.health_data['fatigue'] < 70 and
              18.5 <= self.health_data['bmi'] <= 24.9 and
              self.health_data['sleep_quality'] >= 60 and
              self.health_data['eye_strain'] < 70):
            return "正常"
        else:
            return "需要注意"

    def get_status_color(self, status):
        """根据健康状态返回颜色"""
        if status == "良好":
            return (0, 255, 0)
        elif status == "正常":
            return (255, 255, 0)
        else:
            return (0, 0, 255)

    def detect_faces(self, frame):
        """检测人脸并返回面部特征"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray, 
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30)
        )

        face_features = {'detected': False, 'area': 0, 'distance': 0}
        
        for (x, y, w, h) in faces:
            face_features['detected'] = True
            face_features['area'] = w * h
            face_features['distance'] = frame.shape[0] / h  # 简单估算距离
            
            # 绘制人脸框
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            frame = self.cv2_add_chinese_text(frame,
                '已检���到人脸',
                (x, y-30),
                (0, 255, 0))

        return frame, face_features

    def start_detection(self):
        """开始实时检测"""
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                raise ValueError("无法打开摄像头")
            
            print("开始实时检测，按'q'键退出，按's'键保存截图")
            
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                # 检测人脸并获取面部特征
                frame, face_features = self.detect_faces(frame)
                
                # 显示健康信息
                if face_features['detected']:
                    frame = self.draw_health_info(frame, face_features)
                else:
                    frame = self.cv2_add_chinese_text(frame,
                        "请将人脸对准摄像头",
                        (10, 40),
                        (0, 0, 255))
                
                cv2.imshow('人脸检测与健康监测 (q:退出 s:截图)', frame)
                
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    break
                elif key == ord('s'):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f'健康检测_{timestamp}.jpg'
                    cv2.imwrite(filename, frame)
                    print(f"截图已保存为: {filename}")
                    
        except Exception as e:
            print(f"检测过程中出错: {str(e)}")
            
        finally:
            if 'cap' in locals():
                cap.release()
            cv2.destroyAllWindows()

def main():
    try:
        detector = FaceDetector()
        detector.start_detection()
    except Exception as e:
        print(f"程序运行出错: {str(e)}")

if __name__ == "__main__":
    main() 